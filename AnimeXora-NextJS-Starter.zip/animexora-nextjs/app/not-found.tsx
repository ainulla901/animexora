import Link from 'next/link';
export default function NotFound() { return <main className="not-found"><div className="eyebrow">404 · LOST IN ANOTHER WORLD</div><h1>That page went<br/><span>off-script.</span></h1><p>The page you’re looking for couldn’t be found.</p><Link className="primary-btn" href="/">Return to AnimeXora</Link></main>; }
