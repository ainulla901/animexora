import type { Metadata } from 'next';
import './globals.css';
import Header from '@/components/Header';
export const metadata: Metadata = { title: 'AnimeXora — Your Anime Universe', description: 'Discover anime, explore stories, and find your next favorite series on AnimeXora.', metadataBase: new URL('https://animexora.com') };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body><Header/>{children}<footer className="footer"><div className="brand"><span className="brand-mark">A</span><span>Anime<span className="brand-accent">Xora</span></span></div><p>Discover your next world.</p><small>Anime information provided by Jikan / MyAnimeList. AnimeXora is an independent discovery interface.</small></footer></body></html>; }
