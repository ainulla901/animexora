import Link from 'next/link';
import { Search, Sparkles } from 'lucide-react';
import { searchAnime } from '@/lib/anime';
import AnimeCard from '@/components/AnimeCard';

type SearchParams = Promise<{ q?: string }>;
export default async function SearchPage({ searchParams }: { searchParams: SearchParams }) {
  const { q = '' } = await searchParams;
  const query = q.trim().slice(0, 100);
  const results = query ? await searchAnime(query) : [];
  return <main className="search-page section">
    <div className="eyebrow"><Sparkles size={14}/> DISCOVER YOUR NEXT FAVORITE</div>
    <h1>Search <span className="brand-accent">AnimeXora</span></h1>
    <p className="muted search-intro">Search anime titles and explore series details, genres, scores, and release information.</p>
    <form className="search-form" action="/search" method="get">
      <Search size={20} aria-hidden="true"/>
      <input type="search" name="q" defaultValue={query} maxLength={100} placeholder="Try Naruto, One Piece, or Frieren…" aria-label="Search anime titles"/>
      <button className="primary-btn" type="submit">Search</button>
    </form>
    {query ? <div className="search-results"><div className="section-heading"><div><h2>Results for <span>“{query}”</span></h2><p>{results.length} titles found</p></div><Link href="/search" className="text-link">Clear search</Link></div>{results.length ? <div className="anime-grid">{results.map((a,i)=><AnimeCard anime={a} index={i} key={a.mal_id}/>)}</div> : <div className="empty-state"><Search size={28}/><h3>No titles found</h3><p>Try a shorter title, alternate spelling, or search in English or Japanese romanization.</p></div>}</div> : <div className="empty-state search-hint"><Search size={28}/><h3>What do you want to watch next?</h3><p>Enter an anime title above to find its details.</p></div>}
  </main>;
}
