export type Anime = {
  mal_id: number; title: string; title_english?: string | null; title_japanese?: string | null;
  synopsis?: string | null; images?: { jpg?: { large_image_url?: string; image_url?: string } };
  score?: number | null; year?: number | null; episodes?: number | null;
  genres?: { name: string }[]; type?: string | null; status?: string | null;
};
const API = process.env.NEXT_PUBLIC_JIKAN_API || 'https://api.jikan.moe/v4';
export async function getTopAnime(): Promise<Anime[]> {
  try { const r = await fetch(`${API}/top/anime?filter=bypopularity&limit=12`, { next: { revalidate: 3600 } }); if (!r.ok) return []; const j = await r.json(); return j.data ?? []; } catch { return []; }
}
export async function getAnime(id: string): Promise<Anime | null> {
  if (!/^\d+$/.test(id)) return null;
  try { const r = await fetch(`${API}/anime/${id}/full`, { next: { revalidate: 3600 } }); if (!r.ok) return null; const j = await r.json(); return j.data ?? null; } catch { return null; }
}
export function poster(a: Anime) { return a.images?.jpg?.large_image_url || a.images?.jpg?.image_url || ''; }

export async function searchAnime(query: string): Promise<Anime[]> {
  const clean = query.trim().slice(0, 100);
  if (!clean) return [];
  try {
    const r = await fetch(`${API}/anime?q=${encodeURIComponent(clean)}&limit=18&sfw=true`, { next: { revalidate: 1800 } });
    if (!r.ok) return [];
    const j = await r.json();
    return j.data ?? [];
  } catch {
    return [];
  }
}
