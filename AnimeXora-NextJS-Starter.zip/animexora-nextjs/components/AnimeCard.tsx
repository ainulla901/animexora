import Link from 'next/link';
import { Star } from 'lucide-react';
import type { Anime } from '@/lib/anime';
import { poster } from '@/lib/anime';
export default function AnimeCard({ anime, index = 0 }: { anime: Anime; index?: number }) {
 const image = poster(anime);
 return <Link className="anime-card" href={`/anime/${anime.mal_id}`}>
  <div className="poster-wrap">{image ? <img src={image} alt={`${anime.title} poster`} loading={index < 4 ? 'eager' : 'lazy'}/> : <div className="poster-placeholder">ANIME<br/>XORA</div>}<span className="poster-type">{anime.type || 'Anime'}</span></div>
  <div className="card-meta"><h3>{anime.title_english || anime.title}</h3><div className="card-sub"><span>{anime.year || 'Series'}</span><span className="score"><Star size={12} fill="currentColor"/>{anime.score ?? '—'}</span></div></div>
 </Link>;
}
