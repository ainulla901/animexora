import Link from 'next/link';
import { Search, Compass, Clapperboard } from 'lucide-react';
import LanguageToggle from './LanguageToggle';
export default function Header() { return <header className="header"><Link className="brand" href="/"><span className="brand-mark">A</span><span>Anime<span className="brand-accent">Xora</span></span></Link><nav className="nav"><Link href="/">Home</Link><Link href="/#trending">Trending</Link><Link href="/#discover">Discover</Link></nav><div className="header-actions"><Link className="icon-btn" href="/search" aria-label="Search anime"><Search size={18}/></Link><LanguageToggle/><Link className="explore-btn" href="/#discover"><Compass size={16}/> Explore</Link></div><div className="mobile-brand-icon"><Clapperboard size={20}/></div></header>; }
