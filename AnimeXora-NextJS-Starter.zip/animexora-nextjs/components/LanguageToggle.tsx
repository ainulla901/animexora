'use client';
import { useState } from 'react';
export default function LanguageToggle() {
  const [lang, setLang] = useState<'EN'|'हिं'>('EN');
  return <button className="language" onClick={() => { const next = lang === 'EN' ? 'हिं' : 'EN'; setLang(next); document.documentElement.lang = next === 'EN' ? 'en' : 'hi'; window.dispatchEvent(new CustomEvent('animexora-language', { detail: next })); }} aria-label="Toggle language">{lang}⌄</button>;
}
