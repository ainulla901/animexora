# AnimeXora — Next.js starter

A responsive, dark neon anime discovery website scaffold for AnimeXora. Built with Next.js App Router, TypeScript, Tailwind CSS v4, and Lucide icons. Anime metadata is read from the public Jikan API (MyAnimeList metadata, not video streams).

## Features included
- Responsive homepage with hero, trending/popular anime cards, and discovery sections
- Dynamic anime detail route: `/anime/[id]`
- Watch route: `/watch/[id]?ep=1` with a safe player placeholder
- English/Hindi toggle UI shell (the full copy translation dictionary is a follow-up task)
- Null-safe API handling and custom 404 page
- Vercel-ready project structure
- No login/authentication, matching the current scope

## Run locally
Requires Node.js 20.9+.

```bash
npm install
cp .env.example .env.local
npm run dev
```
Open http://localhost:3000.

## Deploy to Vercel
1. Create a GitHub repository and push this folder's contents.
2. In Vercel, choose **Add New → Project**, import the repository, and keep the Next.js defaults.
3. Add `NEXT_PUBLIC_JIKAN_API=https://api.jikan.moe/v4` if you want to override the API base (optional).
4. Deploy. Connect `animexora.com` under Project → Settings → Domains after you own/configure the domain.

## Important streaming note
Jikan provides anime metadata, not licensed video streams. The watch route deliberately shows a placeholder. Before enabling playback, integrate an official or licensed streaming provider or video URLs you have permission to distribute. Do not scrape or embed unauthorized streams. If you add provider credentials, keep secret values server-side and never put them in `NEXT_PUBLIC_*` variables.

## Production follow-up checklist
- Add a complete translation dictionary so every UI label switches between English and Hindi (current toggle demonstrates language state but does not yet translate all copy).
- Add accessible search and genre filtering.
- Add retry/loading skeletons and API rate-limit handling.
- Configure licensed playback, episode data, and provider terms.
- Add privacy/terms/contact pages and review branding/IP rights before public launch.
- Android: package the deployed site with a compliant WebView/TWA workflow after the website is stable; APK signing and Play Store release are separate steps.


## Android-only deployment (no computer required)

1. Download the project ZIP from the ChatGPT conversation and save it to your phone.
2. In Chrome, open GitHub and create a new **public or private** repository named `animexora` (keep it empty; do not add a README). Sign in or create a GitHub account.
3. Open GitHub's web upload interface for the new repository. Extract the ZIP on your phone using your Files app, then upload the project files and folders from the extracted `animexora-nextjs` directory to the repository root. Make sure `app`, `components`, `lib`, `package.json`, `tsconfig.json`, and `next.config.ts` are at the root, not nested inside another folder. If mobile upload is awkward, use GitHub's `Add file` upload flow in Chrome desktop-site mode.
4. Open https://vercel.com in Chrome and sign in with GitHub. Choose **Add New → Project**, import the `animexora` repository, keep the detected Next.js framework and default build settings, then press **Deploy**.
5. Wait for the deployment to finish and open the provided `.vercel.app` URL. Try the homepage, open an anime card, and search for a title using `/search`.
6. To publish changes later, upload/commit the changed files to GitHub. Vercel will automatically build and deploy the updated commit.

### Important notes
- The project uses Jikan's public anime metadata API. It can occasionally rate-limit or return no results; the app shows a friendly empty state in that case.
- No login is required or included.
- Episode pages are intentionally a placeholder until you configure a licensed streaming provider or official embed. Anime metadata access does not grant streaming rights.
- `animexora.com` is connected separately in Vercel under **Project → Settings → Domains**. You must own the domain and update the DNS records Vercel gives you. The starter does not automatically own or register it.
- A phone browser can manage the repo and deployment, but editing many files on a phone is easier with a browser editor or GitHub's web editor. Never paste passwords, API secrets, or access tokens into chat.
